import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'userhome',
    templateUrl:'../_html/app.userhome.html'
})
export class UserHomeComponent implements OnInit{
    constructor()
    {console.log("DEBUG");
}
    
    ngOnInit() {
    }

}