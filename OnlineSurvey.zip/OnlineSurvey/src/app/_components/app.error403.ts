import {Component} from '@angular/core';

@Component({
    selector:'error403',
    templateUrl:'../_html/app.error403.html'
})
export class Error403Component{

}