import { Component } from "@angular/core";
import { HcsService } from "../_service/app.hcsservice";
import { SurveyModel } from "../_model/app.surveymodel";
import { QuestionModel } from "../_model/app.questionmodel";

@Component({
    selector:'addquestion',
    templateUrl:'../_html/app.addquestion.html'
})
export class AddQuestionComponent
{
    surveyList:SurveyModel[]=[];
   // model: QuestionModel={questionId:null,questionDescription:null,questionType:null,questionOptions:null};
    model:any={};
    errorMessage: any;
    QuestionType:String[]=["singlechoice","multiplechoice","singleline","multiline"];
    sMsg:string = '';
    survey1:SurveyModel={surveyId:null,surveyType:null,surveyDescription:null,surveyName:null};
    //survey1:SurveyModel;

    constructor(private service:HcsService){
        
    }
    ngOnInit(): void {
      
        this.service.getSurvey().subscribe((surveyListS:SurveyModel[]) => this.surveyList = surveyListS);
        console.log(this.surveyList);
    }
    addQuestion(surveyId:any):any
    {
        alert(this.model)
       if(surveyId!=undefined && surveyId!=null)
        this.service.addQuestion(surveyId,this.model).subscribe((data:any)=>{alert("Question added successfully");
       
        
        location.reload();
        
    },error => this.errorMessage= error.error);
       
    }
    


   
}