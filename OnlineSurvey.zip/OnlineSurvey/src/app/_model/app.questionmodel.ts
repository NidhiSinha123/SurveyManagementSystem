export class QuestionModel
{
    questionId:any;
    questionDescription:String;
    questionType:String;
    questionOptions:String[]=[];
}