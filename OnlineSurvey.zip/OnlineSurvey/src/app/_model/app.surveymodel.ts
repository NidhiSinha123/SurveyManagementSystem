export class SurveyModel
{
    surveyId:any;
    surveyName:String;
    surveyType:String;
    surveyDescription:String
}