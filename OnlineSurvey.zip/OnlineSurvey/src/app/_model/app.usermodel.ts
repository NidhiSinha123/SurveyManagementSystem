import { SurveyModel } from "./app.surveymodel";

export class UserModel{
    userId:any;
    userPassword:any;
    userName:any;
    contactNo:any;
    userRole:any;
    userEmail:any;
    age:any;
    gender:any;
    status:any;
}